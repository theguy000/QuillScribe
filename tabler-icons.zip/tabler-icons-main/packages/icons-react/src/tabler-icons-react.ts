export * from './icons';
export * as icons from './icons';
export * as iconsList from './icons-list';
export * from './aliases';
export * from './types';

export { default as createReactComponent } from './createReactComponent';
